<?php
$config = (object) [
    "db_config" => (object) [
        "db_username" => "dev",
        "db_password" => "dev",
        "db_name"     => "youtube",
        "db_host"     => "mysql",
    ],
];