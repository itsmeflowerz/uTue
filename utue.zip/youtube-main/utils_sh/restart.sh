#!/bin/bash
# Start up a local Pebbbles instance. 

# nginx: http://localhost:8000
# phpma: http://localhost:8000

docker-compose down && docker-compose up -d